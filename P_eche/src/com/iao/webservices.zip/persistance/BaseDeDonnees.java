package com.iao.persistance;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import java.sql.*;



/**
 * @author mohamed boudouar
 *
 */
public class BaseDeDonnees {
	public static String getString(Date d) {
		   return new SimpleDateFormat("yyyy-MM-dd").format(d);
		}

	private Connection connection;

	public BaseDeDonnees() throws ClassNotFoundException, SQLException {

	//	Class.forName("com.mysql.jdbc.Driver");
		Class.forName("com.mysql.cj.jdbc.Driver");

		//connection = DriverManager.getConnection("jdbc:mysql://46.101.50.30:3306/si?createDatabaseIfNotExist=true",
			//	"root", "yakada");
		
		String url = "jdbc:mysql://localhost/si?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String utilisateur = "root";
        String motDePasse = "";
        
        connection = DriverManager.getConnection( url, utilisateur, motDePasse );
           // connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/si?createDatabaseIfNotExist=true",
			//		"root", "");

	}
	public Connection getConnection() {
		return connection;
	}
	


}