package com.iao.entities;
import com.iao.services.*;

import java.sql.SQLException;

public class Test {

	public static void main(String[] args) {
		
		
		/*Client c=new Client("smia","knia","0661","mail@gmail.com");
		try {
			Client.addClient(c);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		/*Reservation r=new Reservation("2018-11-14","2018-11-14","2018-11-14",1,1);
		try {
			//Reservation.addReservation(r);
		//	Reservation.confirmReserv(1);
			
			Client.updateClient(1, "sla", "chfar", 0.0);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		
		//System.out.println(Reservation.annuleReserv(3));
		WebServices x=new WebServices();
		System.out.println(x.procederReservDefinit(2));
		
		//x.annuleReserv(2);
		
		//System.out.println(x.creeClient("djd", "pjre", "066", "ddhd@d.c"));
		//System.out.println(x.getFacture(1));
		
		
		//Facture f=Facture.getFacture(1);
		//System.out.println(f.getMontant());
		
		//System.out.println(Facture.finPaiement(1));
		
		
		
		/*try {
			Reservation.confirmReserv(2);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
	/*	try {
			Paiement.enregistrerPaiement(1,1000);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		//Facture.rembourser(1);
		
		
	}

}

