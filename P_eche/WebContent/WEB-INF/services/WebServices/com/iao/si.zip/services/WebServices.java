package com.iao.services;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.iao.entities.Client;
import com.iao.entities.Facture;
import com.iao.entities.Paiement;
import com.iao.entities.Reservation;
import com.iao.persistance.BaseDeDonnees;

public class WebServices {
		public void creeClient(String nom,String prenom,String telephone,String email) throws ClassNotFoundException, SQLException {
			Client c=new Client(nom,prenom,telephone,email);
			c.addClient(c);
			
		}
		
		public void creeReservation(String date_res, String date_debut, String date_fin, int id_voyage, int num_cli) {
			Reservation r=new Reservation(date_res, date_debut,  date_fin, id_voyage, num_cli);
			try {
				Reservation.addReservation(r);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		public void confirmPreres(int num_res) throws ClassNotFoundException, SQLException {
			
			Reservation.confirmReserv(num_res);
		}
		
		public void preparationDossier(int num_cli,String adresse,String profession, double revenue_mensuel) {
				
		}
		
		public void etudeDossier(int num_cli) {
			
		}
		
		public void procederReservDefinit(int num_res) {
			
			
		}
		public void payeecheance(double somme,int num_fac) {
			//incrementer la somme total bla somme li ghayched db
			
			try {
				Facture.receptionPaiement( num_fac,somme);
				Paiement.enregistrerPaiement(num_fac, somme);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		public void getFacture(int num_fac) {
			Facture.getFacture(num_fac);
			
		}
		public void finPaiement(int num_fac) {
			Facture.finPaiement(num_fac);
		}
		
		
		public void annuleReserv(int num_res) {
			//set type_reservation= reserv annulle;
			// confirmation annulle;
			Reservation.annuleReserv(num_res);
			
		}
		
		public void rembourser(int num_fac) {
			//facture setAccompte=accompte*0.02;
			Facture.rembourser(num_fac);
		}
		
		
		public void paiementImmediat(double somme,int num_fac) {
			//incrementer la somme 
			
			try {
				Facture.receptionPaiement( num_fac,somme);
				Paiement.enregistrerPaiement(num_fac, somme);
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			//Reservation.confirmReserv(num_res);
			//
		}
		
			
		
}
